def count_vowels_consonants(input_str):
    vowels = "aeiouAEIOU"
    vowel_count = 0
    consonant_count = 0
    i = 0
    while i < len(input_str):
        ch = input_str[i]
        if ('A' <= ch <= 'Z') or ('a' <= ch <= 'z'):
            is_vowel = 0
            j = 0
            while j < len(vowels):
                if ch == vowels[j]:
                    is_vowel = 1
                    break
                j += 1
            if is_vowel == 1:
                vowel_count += 1
            else:
                consonant_count += 1
        i += 1
    return vowel_count, consonant_count

s = input()
result1 = count_vowels_consonants(s)
print(result1)
