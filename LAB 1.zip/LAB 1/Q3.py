def count_common_elements(l1, l2, n1, n2):
    count = 0
    i = 0
    while i < n1:
        j = 0
        found = 0
        while j < n2:
            if l1[i] == l2[j]:
                found = 1
                break
            j += 1
        if found == 1:
            count += 1
        i += 1
    return count

n1 = int(input())
list1 = []
i = 0
while i < n1:
    val = int(input())
    list1.append(val)
    i += 1

n2 = int(input())
list2 = []
i = 0
while i < n2:
    val = int(input())
    list2.append(val)
    i += 1

result3 = count_common_elements(list1, list2, n1, n2)
print(result3)
