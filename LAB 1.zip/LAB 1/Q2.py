def multiply_matrices(A, B, r1, c1, r2, c2):
    if c1 != r2:
        return "Error"
    result = []
    i = 0
    while i < r1:
        row = []
        j = 0
        while j < c2:
            total = 0
            k = 0
            while k < c1:
                total += A[i][k] * B[k][j]
                k += 1
            row.append(total)
            j += 1
        result.append(row)
        i += 1
    return result

r1 = int(input())
c1 = int(input())
A = []
i = 0
while i < r1:
    row = []
    j = 0
    while j < c1:
        val = int(input())
        row.append(val)
        j += 1
    A.append(row)
    i += 1

r2 = int(input())
c2 = int(input())
B = []
i = 0
while i < r2:
    row = []
    j = 0
    while j < c2:
        val = int(input())
        row.append(val)
        j += 1
    B.append(row)
    i += 1

result2 = multiply_matrices(A, B, r1, c1, r2, c2)
print(result2)
