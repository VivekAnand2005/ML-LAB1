def custom_random(seed):
    seed = (seed * 1103515245 + 12345) % (2**31)
    return seed

def generate_random_list(size, low, high):
    nums = []
    seed = 1
    i = 0
    while i < size:
        seed = custom_random(seed)
        val = low + (seed % (high - low + 1))
        nums.append(val)
        i += 1
    return nums

def calculate_mean(arr):
    total = 0
    i = 0
    while i < len(arr):
        total += arr[i]
        i += 1
    return total // len(arr)

def sort_array(arr):
    n = len(arr)
    i = 0
    while i < n:
        j = 0
        while j < n - i - 1:
            if arr[j] > arr[j + 1]:
                temp = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = temp
            j += 1
        i += 1
    return arr

def calculate_median(arr):
    arr = sort_array(arr)
    n = len(arr)
    if n % 2 == 0:
        return (arr[n//2] + arr[n//2 - 1]) // 2
    else:
        return arr[n//2]

def calculate_mode(arr):
    max_count = 0
    mode_val = arr[0]
    i = 0
    while i < len(arr):
        count = 0
        j = 0
        while j < len(arr):
            if arr[j] == arr[i]:
                count += 1
            j += 1
        if count > max_count:
            max_count = count
            mode_val = arr[i]
        i += 1
    return mode_val

rand_nums = generate_random_list(100, 100, 150)
mean = calculate_mean(rand_nums)
median = calculate_median(rand_nums)
mode = calculate_mode(rand_nums)
print(mean, median, mode)
